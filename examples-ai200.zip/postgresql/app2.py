import psycopg2
from openai import AzureOpenAI

client = AzureOpenAI(
    api_key="88nTF3lw4tnLX2AJ2rQ1VKPELE7q5gpdJa95DVJ1fTEC7636cG1TJQQJ99CFACHYHv6XJ3w3AAAAACOGdbMa",
    api_version="2024-02-01",
    azure_endpoint="https://makar-mqhfln3h-eastus2.openai.azure.com"
)

question = "How can I securely store passwords?"

response = client.embeddings.create(
    model="text-embedding-3-small",
    input=question
)

query_vector = response.data[0].embedding

vector_string = "[" + ",".join(map(str, query_vector)) + "]"

conn = psycopg2.connect(
    host="pgsql1015.postgres.database.azure.com",
    database="postgres",
    user="makarand",
    password="Complex#1234",
    sslmode="require"
)

cursor = conn.cursor()

cursor.execute(
    """
    SELECT
        service_name,
        description,
        embedding <=> %s::vector AS distance
    FROM knowledgebase
    ORDER BY embedding <=> %s::vector
    LIMIT 1
    """,
    (vector_string, vector_string)
)

for row in cursor.fetchall():
    print(row)

cursor.close()
conn.close()