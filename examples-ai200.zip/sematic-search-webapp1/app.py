import os
from flask import Flask, render_template, request

app = Flask(__name__)

EMBEDDING_MODEL = os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")

TOP_N = int(os.getenv("SEARCH_TOP_N", "5"))


def get_openai_client():
    from openai import AzureOpenAI

    return AzureOpenAI(
        api_key=os.getenv("AZURE_OPENAI_API_KEY", "wvFy9zgvO826sJYV3v0H6ZHLrORB5FxGqxVKFLziTLfwLpPqxzIeJQQJ99CFACHYHv6XJ3w3AAAAACOGtB9Z"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://makarandbhoir-2566-resource.openai.azure.com"),
    )


def get_container_client():
    from azure.cosmos import CosmosClient

    cosmos_client = CosmosClient(
        os.getenv("COSMOS_ENDPOINT", "https://wipro-retaildb.documents.azure.com:443/"),
        os.getenv("COSMOS_KEY", "36S4EfZox5EG6vWWUKN71HVG5dOLMXTjsuD5k2gmSSA9NzHEaxqQYaery6mdMq6GvWzz3oK06GwBACDb3mB1jQ=="),
    )
    database = cosmos_client.get_database_client(os.getenv("COSMOS_DATABASE", "RetailDB"))
    return database.get_container_client(os.getenv("COSMOS_CONTAINER", "Products"))


def get_query_embedding(text: str) -> list[float]:
    openai_client = get_openai_client()
    response = openai_client.embeddings.create(model=EMBEDDING_MODEL, input=text)
    return response.data[0].embedding


def semantic_search(query: str, top_n: int = TOP_N) -> list[dict]:
    container = get_container_client()
    query_embedding = get_query_embedding(query)

    vector_sql = f"""
        SELECT TOP {top_n}
            c.id,
            c.name,
            c.category,
            c.description,
            VectorDistance(c.embedding, @query_embedding) AS similarity_score
        FROM c
        ORDER BY VectorDistance(c.embedding, @query_embedding)
    """

    results = container.query_items(
        query=vector_sql,
        parameters=[{"name": "@query_embedding", "value": query_embedding}],
        enable_cross_partition_query=True,
    )

    return list(results)


@app.route("/health")
def health():
    return {"status": "ok"}, 200


@app.route("/", methods=["GET", "POST"])
def index():
    results = []
    query = ""
    error = None

    if request.method == "POST":
        query = request.form.get("query", "").strip()
        if query:
            try:
                results = semantic_search(query)
            except Exception as exc:
                error = str(exc)

    return render_template("index.html", query=query, results=results, error=error)


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    app.run(host="0.0.0.0", port=port, debug=False)
