import os
from openai import AzureOpenAI
from azure.cosmos import CosmosClient, PartitionKey

# 1. Initialize Azure OpenAI Client
# Ensure AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY environment variables are set
client = AzureOpenAI(
    api_key="wvFy9zgvO826sJYV3v0H6ZHLrORB5FxGqxVKFLziTLfwLpPqxzIeJQQJ99CFACHYHv6XJ3w3AAAAACOGtB9Z",
    api_version="2024-02-01",
    azure_endpoint="https://makarandbhoir-2566-resource.openai.azure.com"
)

# 2. Initialize Azure Cosmos DB Client
# Ensure COSMOS_ENDPOINT and COSMOS_KEY environment variables are set
COSMOS_ENDPOINT = os.getenv("COSMOS_ENDPOINT", "https://wipro-retaildb.documents.azure.com:443/")
COSMOS_KEY = os.getenv("COSMOS_KEY", "36S4EfZox5EG6vWWUKN71HVG5dOLMXTjsuD5k2gmSSA9NzHEaxqQYaery6mdMq6GvWzz3oK06GwBACDb3mB1jQ==")

cosmos_client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
database = cosmos_client.get_database_client("RetailDB")
container = database.get_container_client("Products")

# 3. Define the Source Dataset
products = [
    { "id": "101", "category": "Laptop", "name": "Surface Laptop 6", "description": "Lightweight business laptop" },
    { "id": "102", "category": "Phone", "name": "Samsung Galaxy S25", "description": "Android smartphone with AI features" },
    { "id": "103", "category": "Tablet", "name": "iPad Air", "description": "Portable tablet for productivity and creativity" },
    { "id": "104", "category": "Monitor", "name": "Dell UltraSharp 27", "description": "High-resolution monitor for professionals" },
    { "id": "105", "category": "Printer", "name": "HP LaserJet Pro", "description": "Wireless laser printer for office use" },
    { "id": "106", "category": "Keyboard", "name": "Logitech MX Keys", "description": "Wireless keyboard designed for productivity" },
    { "id": "107", "category": "Mouse", "name": "Logitech MX Master 3S", "description": "Ergonomic mouse for multitasking" },
    { "id": "108", "category": "Headphone", "name": "Sony WH-1000XM5", "description": "Noise-canceling wireless headphones" },
    { "id": "109", "category": "Camera", "name": "Canon EOS R8", "description": "Mirrorless camera for photography enthusiasts" },
    { "id": "110", "category": "Smartwatch", "name": "Apple Watch Series 10", "description": "Health and fitness tracking smartwatch" },
    { "id": "111", "category": "Television", "name": "Samsung Neo QLED", "description": "4K smart television with vibrant display" },
    { "id": "112", "category": "Refrigerator", "name": "LG InstaView", "description": "Smart refrigerator with energy-efficient cooling" },
    { "id": "113", "category": "Washing Machine", "name": "Bosch Series 6", "description": "Front-load washing machine with eco mode" },
    { "id": "114", "category": "Air Conditioner", "name": "Daikin Inverter AC", "description": "Energy-saving split air conditioner" },
    { "id": "115", "category": "Microwave", "name": "Panasonic NN-ST34", "description": "Convection microwave oven for quick cooking" },
    { "id": "116", "category": "Furniture", "name": "IKEA Markus Chair", "description": "Ergonomic office chair for long working hours" },
    { "id": "117", "category": "Book", "name": "Azure AI Fundamentals", "description": "Comprehensive guide to Azure AI services" },
    { "id": "118", "category": "Vehicle", "name": "Honda City", "description": "Reliable sedan with excellent fuel efficiency" },
    { "id": "119", "category": "Sports", "name": "Yonex Astrox 100", "description": "Professional badminton racket" },
    { "id": "120", "category": "Food", "name": "Organic Almonds", "description": "Healthy snack rich in nutrients" },
    { "id": "121", "category": "Laptop", "name": "Surface Laptop 6", "description": "Lightweight business laptop" },
    { "id": "122", "category": "Laptop", "name": "ThinkPad X1", "description": "Durable laptop for business travelers" },
    { "id": "123", "category": "Laptop", "name": "Dell XPS 15", "description": "Premium productivity laptop" },
    { "id": "124", "category": "Phone", "name": "Samsung Galaxy", "description": "Android smartphone with AI features" }
]

# 4. Process and Store Products
for product in products:
    try:
        print(f"Generating embedding for: {product['name']}...")
        
        # Call Azure OpenAI to generate vector embeddings
        response = client.embeddings.create(
            model="text-embedding-3-small",  # Replace with your specific deployment name
            input=product["description"]
        )
        
        # Extract vector array from the response object
        embedding = response.data[0].embedding
        
        # Inject the generated vector embedding into our item payload
        product["embedding"] = embedding
        
        # Save or overwrite the item in Azure Cosmos DB
        container.upsert_item(product)
        print(f"Successfully saved {product['name']} to Cosmos DB.\n")
        
    except Exception as e:
        print(f"Failed to process {product['name']}. Error: {e}\n")

print("All items processed.")
