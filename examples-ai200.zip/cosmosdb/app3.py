import os
import json
from openai import AzureOpenAI
from azure.cosmos import CosmosClient

# 1. Initialize Azure OpenAI Client
client = AzureOpenAI(
    api_key="wvFy9zgvO826sJYV3v0H6ZHLrORB5FxGqxVKFLziTLfwLpPqxzIeJQQJ99CFACHYHv6XJ3w3AAAAACOGtB9Z",
    api_version="2024-02-01",
    azure_endpoint="https://makarandbhoir-2566-resource.openai.azure.com"
)

# 2. Initialize Azure Cosmos DB Client
COSMOS_ENDPOINT = os.getenv("COSMOS_ENDPOINT", "https://wipro-retaildb.documents.azure.com:443/")
COSMOS_KEY = os.getenv("COSMOS_KEY", "Mowwe3SgGmkTNUS6XuPCotEuZwEehb5W4vuWDOX2yH6THMpPjkCWm4vVy1IvioeEFgBtVxPjx5fGACDbM9bJqw==")

cosmos_client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
database = cosmos_client.get_database_client("RetailDB")
container = database.get_container_client("Products")

# 3. Define the Search String
search_query = "portable computer for work trips"
# search_query = "college student looking for a lightweight laptop for assignments and projects"
# search_query = "coding laptop with good battery life and performance"

print(f"User Search Query: '{search_query}'\n")

try:
    # 4. Convert the user query text into a vector embedding
    response = client.embeddings.create(
        model="text-embedding-3-small",  # Must match the model used to seed your database
        input=search_query
    )
    query_embedding = response.data[0].embedding

    # 5. Define the NoSQL Vector Search Query
    # VectorDistance computes similarity. ORDER BY ranks them closest-to-furthest.
    vector_search_sql = """
        SELECT TOP 1 
            c.id, 
            c.name, 
            c.category, 
            c.description, 
            VectorDistance(c.embedding, @query_embedding) AS SimilarityScore 
        FROM c 
        ORDER BY VectorDistance(c.embedding, @query_embedding)
    """

    # 6. Execute Vector Query against Cosmos DB Container
    search_results = container.query_items(
        query=vector_search_sql,
        parameters=[
            {"name": "@query_embedding", "value": query_embedding}
        ],
        enable_cross_partition_query=True
    )

    # 7. Print Ranked Search Results
    print("--- Top Semantic Search Results ---")
    for item in search_results:
        print(f"Product: {item.get('name')} ({item.get('category')})")
        print(f"Description: {item.get('description')}")
        print(f"Distance Score: {item.get('SimilarityScore'):.4f}")
        print("-" * 40)

except Exception as e:
    print(f"An error occurred during vector search: {e}")
