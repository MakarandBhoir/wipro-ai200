from openai import AzureOpenAI
import psycopg2

# Azure OpenAI
client = AzureOpenAI(
    api_key="88nTF3lw4tnLX2AJ2rQ1VKPELE7q5gpdJa95DVJ1fTEC7636cG1TJQQJ99CFACHYHv6XJ3w3AAAAACOGdbMa",
    api_version="2024-02-01",
    azure_endpoint="https://makar-mqhfln3h-eastus2.openai.azure.com"
)

# PostgreSQL Connection
conn = psycopg2.connect(
    host="pgsql1015.postgres.database.azure.com",
    database="postgres",
    user="makarand",
    password="Complex#1234",
    sslmode="require"
)

cursor = conn.cursor()

# Sample Documents
documents = [
    (
        "Key Vault",
        "Azure Key Vault stores secrets securely"
    ),
    (
        "Blob Storage",
        "Azure Blob Storage stores files and images"
    ),
    (
        "App Service",
        "Azure App Service hosts web applications"
    ),
    (
        "Virtual Machines",
        "Azure Virtual Machines provide compute resources"
    ),
    (
        "Cosmos DB",
        "Azure Cosmos DB is a NoSQL database"
    )
]

for service_name, description in documents:

    # Generate Embedding
    response = client.embeddings.create(
        model="text-embedding-3-small",  # your deployment name
        input=description
    )

    embedding = response.data[0].embedding

    # Convert list to pgvector format
    vector_string = "[" + ",".join(map(str, embedding)) + "]"

    cursor.execute(
        """
        INSERT INTO knowledgebase
        (service_name, description, embedding)
        VALUES (%s, %s, %s)
        """,
        (
            service_name,
            description,
            vector_string
        )
    )

    print(f"Inserted: {service_name}")

conn.commit()

cursor.close()
conn.close()

print("All records inserted successfully.")