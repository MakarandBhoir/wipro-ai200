"""Simple Python app that saves a product to Cosmos DB and sends a Service Bus notification."""

import json
import uuid
from datetime import datetime, timezone

from azure.cosmos import CosmosClient
from azure.servicebus import ServiceBusClient, ServiceBusMessage


COSMOS_ENDPOINT = "https://wipro-retaildb.documents.azure.com:443/"
COSMOS_KEY = "36S4EfZox5EG6vWWUKN71HVG5dOLMXTjsuD5k2gmSSA9NzHEaxqQYaery6mdMq6GvWzz3oK06GwBACDb3mB1jQ=="
COSMOS_DATABASE_NAME = "RetailDB"
COSMOS_CONTAINER_NAME = "Products"

SERVICE_BUS_CONNECTION_STRING = "Endpoint=sb://wipro-service-bus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=aopDwp1rb5UrScCpOkXzQdsuE2Z3+qrEH+ASbDiZGI0="
QUEUE_NAME = "product-queue"

product = {
    "id": "128",
    "category": "electronics",
    "name": "Noise Cancelling Headphones",
    "description": "Wireless over-ear headphones with active noise cancellation.",
}

cosmos_client = CosmosClient(COSMOS_ENDPOINT, credential=COSMOS_KEY)
database = cosmos_client.get_database_client(COSMOS_DATABASE_NAME)
container = database.get_container_client(COSMOS_CONTAINER_NAME)
container.upsert_item(body=product)

print("Document saved to Cosmos DB.")

event = {
    "event_id": str(uuid.uuid4()),
    "event_type": "product.updated",
    "occurred_at_utc": datetime.now(timezone.utc).isoformat(),
    "source": "product-app",
    "container": COSMOS_CONTAINER_NAME,
    "product": product,
}

message = ServiceBusMessage(
    body=json.dumps(event),
    content_type="application/json",
    subject=event["event_type"],
    message_id=event["event_id"],
)

servicebus_client = ServiceBusClient.from_connection_string(SERVICE_BUS_CONNECTION_STRING)
with servicebus_client:
    sender = servicebus_client.get_queue_sender(queue_name=QUEUE_NAME)
    with sender:
        sender.send_messages(message)

print("Message sent to Service Bus queue.")
print(json.dumps(event, indent=2))