from openai import AzureOpenAI

client = AzureOpenAI(
    api_key="wvFy9zgvO826sJYV3v0H6ZHLrORB5FxGqxVKFLziTLfwLpPqxzIeJQQJ99CFACHYHv6XJ3w3AAAAACOGtB9Z",
    api_version="2024-02-01",
    azure_endpoint="https://makarandbhoir-2566-resource.openai.azure.com"
)

response = client.embeddings.create(
    model="text-embedding-3-small",
    input="portable computer for work trips"
)

embedding = response.data[0].embedding

print(len(embedding))
print(embedding[:100])  # Print the first 10 dimensions of the embedding